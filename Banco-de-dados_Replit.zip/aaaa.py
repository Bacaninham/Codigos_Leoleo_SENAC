import sqlite3  # importa o módulo sqlite3 para trabalhar com o banco de dados
import time  # importa o módulo time para adicionar pausas no código

class Banco:
    def __init__(self):
        self.conn = sqlite3.connect("banco.bd")  # conecta-se ao banco de dados "banco.bd"
        self.cursor = self.conn.cursor()  # cria um cursor para executar consultas SQL no banco de dados
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome VARCHAR(50),
            cpf VARCHAR(11),
            saldo DECIMAL(10, 2),
            cargo VARCHAR(20),
            senha VARCHAR(50)
        );
        ''')  # cria a tabela "usuarios" no banco de dados se ela ainda não existir
        self.conn.commit()  # salva as alterações no banco de dados
        self.cargo_atual = "cliente"  # define o cargo padrão como "cliente"
        self.transferencias_programadas = {}  # cria um dicionário vazio para armazenar transferências programadas
        self.Chave_definida = "123456"  # define a chave de acesso do administrador
        self.contas = {}  # cria um dicionário vazio para armazenar contas
        self.adms = {}  # cria um dicionário vazio para armazenar administradores
        self.reclamacoes = {}  # cria um dicionário vazio para armazenar reclamações

    def transferir(self, origem_cpf, destino_cpf, valor, tipo_transferencia):
        if not self.verificar_existencia_usuario(origem_cpf) or not self.verificar_existencia_usuario(destino_cpf):
            print("CPF de origem ou destino não encontrado. A transferência não pode ser realizada.")
            return  # verifica se o CPF de origem ou destino existe no banco de dados, se não existir, a transferência não é realizada

        if tipo_transferencia == "pix":
            if self.sacar(origem_cpf, valor):
                self.adicionar_saldo(destino_cpf, valor)
                print(f"Transferência PIX de R${valor:.2f} realizada com sucesso.")
        elif tipo_transferencia == "ted":
            if origem_cpf not in self.transferencias_programadas:
                self.transferencias_programadas[origem_cpf] = {}
            self.transferencias_programadas[origem_cpf][destino_cpf] = valor
            print(f"Transferência TED de R${valor:.2f} programada para ser realizada em 1 minuto.")
            time.sleep(60)  # pausa o código por 1 minuto para simular a transferência TED
            if origem_cpf in self.transferencias_programadas and destino_cpf in self.transferencias_programadas[origem_cpf]:
                valor_ted = self.transferencias_programadas[origem_cpf].pop(destino_cpf)
                if self.sacar(origem_cpf, valor_ted):
                    self.adicionar_saldo(destino_cpf, valor_ted)
                    print(f"Transferência TED de R${valor_ted:.2f} realizada com sucesso.")

    def sacar(self, cpf_saque, valor_saque):
        if self.verificar_existencia_usuario(cpf_saque):
            if self.verificar_saldo_suficiente(cpf_saque, valor_saque):
                self.cursor.execute("UPDATE usuarios SET saldo = saldo - ? WHERE cpf = ?", (valor_saque, cpf_saque))
                self.conn.commit()
