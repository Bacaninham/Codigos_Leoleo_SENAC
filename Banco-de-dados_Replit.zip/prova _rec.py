# Definição da classe Elevador
class Elevador:
    # Método construtor da classe, que recebe a capacidade do elevador como parâmetro
    def __init__(self, capacidade=0):
        # Instanciação do atributo "capacidade"
        self.capacidade = capacidade
        # Instanciação do atributo "contador", que será utilizado para contar o número de pessoas no elevador
        self.contador = 0

    # Método "Entrar", que adiciona pessoas ao elevador
    def Entrar(self):
        # Recebe o número de pessoas que irão entrar no elevador
        entrada = int(input('Quantas pessoas irão entrar no elevador?\n'))
        # Verifica se o número de pessoas não excede a capacidade restante do elevador
        if entrada <= 10:
            # Incrementa o contador de pessoas no elevador
            self.contador += entrada
            # Imprime a mensagem informando a quantidade de pessoas adicionadas e o total no elevador
            print(f'Foram adicionadas {entrada} pessoas\nTotal: {self.contador}')
        else:
            # Imprime a mensagem informando que o elevador está cheio
            print('O elevador está cheio')

    # Método "Sair", que remove uma pessoa do elevador
    def Sair(self):
        # Verifica se há pelo menos uma pessoa no elevador
        if self.contador > 0:
            # Decrementa o contador de pessoas no elevador
            self.contador -= 1
            # Imprime a mensagem informando que uma pessoa foi removida e o total no elevador
            print(f'Foi removida uma pessoa\nTotal: {self.contador}')
        else:
            # Imprime a mensagem informando que não há pessoas no elevador
            print('Não há pessoas no elevador')

    # Método "Subir", que move o elevador para cima em um andar
    def Subir(self):
        # Define o número total de andares
        total_andares = 10
        # Recebe o andar para onde o elevador deve subir
        andar_subir = int(input('Digite de 0 a 10 o andar que desejar subir\n'))
        # Verifica se o andar é válido
        if andar_subir <= total_andares:
            # Imprime a mensagem informando que o elevador subiu para o andar desejado
            print(f'O elevador subiu para o andar: {andar_subir}')
        else:
            # Imprime a mensagem informando que não é possível subir mais estando no último andar
            print('Não há como subir estando no último andar')

    # Método "Descer", que move o elevador para baixo em um andar
    def Descer(self):
        # Recebe o andar para onde o elevador deve descer
        andar_descer = int(input('Digite de 0 a 10 o andar que deseja descer\n'))
        # Verifica se o andar é válido
        if andar_descer > 0:
            # Imprime a mensagem informando que o elevador desceu para o andar desejado
            print(f'O elevador desceu para o andar: {andar_descer} ')
        else:
            # Imprime a mensagem informando que não é possível descer mais estando no térreo
            print('Não há como descer estando no térreo')

# Recebe a opção escolhida pelo usuário
opc = int(input('O que deseja fazer?\n1-Entrar\n2-Sair\n3-Subir\n4-Descer\n'))
# chamando os metodos a partir da escolha do usuário
if opc == 1:
    objeto = Elevador(capacidade=10)
    objeto.Entrar()
elif opc == 2:
    objeto = Elevador()
    objeto.Sair()
elif opc == 3:
    objeto = Elevador()
    objeto.Subir()
elif opc == 4:
    objeto = Elevador()
    objeto.Descer()
else:
    print('Opção inválida!')